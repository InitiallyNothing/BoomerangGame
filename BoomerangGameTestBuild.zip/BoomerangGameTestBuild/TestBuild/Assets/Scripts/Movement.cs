﻿using UnityEngine;
using System.Collections;
public class Movement : MonoBehaviour
{
    public float speed = 10f;
    public float jumpSpeed = 7f;
    private float movement = 0f;
    private Rigidbody2D myRigidBody;
    bool isGrounded = false;
    public float jumpForce = 50000f;

    //vine
    bool isOnVine = false;
    
 


 
    // Use this for initialization
    void Start()
    {
        myRigidBody = GetComponent<Rigidbody2D>();
 
    }

    // Update is called once per frame
    void Update()
    {
        isGrounded = Physics2D.IsTouchingLayers(GetComponent<Collider2D>(), LayerMask.GetMask("Ground"));
        isOnVine = Physics2D.IsTouchingLayers(GetComponent<Collider2D>(), LayerMask.GetMask("Climbables"));

        movement = Input.GetAxis("Horizontal");

        if (movement > 0f)
        {
            myRigidBody.velocity = new Vector2(movement * speed, myRigidBody.velocity.y);
            transform.localScale = new Vector2(-0.7115098f, 0.4760615f);
          
        }
        else if (movement < 0f)
        {
            myRigidBody.velocity = new Vector2(movement * speed, myRigidBody.velocity.y);
            transform.localScale = new Vector2(0.7115098f, 0.4760615f);
          
        }
        else
        {
            myRigidBody.velocity = new Vector2(0, myRigidBody.velocity.y);
        }
        if ((Input.GetButtonDown("Jump")&& isGrounded))
        {
            myRigidBody.velocity = new Vector2(myRigidBody.velocity.x, jumpSpeed);
        }
        if ((Input.GetButtonDown("Jump") && isOnVine))
        {
            myRigidBody.velocity = new Vector2(myRigidBody.velocity.x, jumpSpeed);
        }

    }
}